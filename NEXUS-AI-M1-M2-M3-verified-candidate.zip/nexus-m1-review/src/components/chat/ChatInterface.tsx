"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { Message } from "@/lib/types";
import { MessageBubble } from "./MessageBubble";
import { ChatInput } from "./ChatInput";
import { EmptyState } from "@/components/states/EmptyState";
import { AlertCircle, MessageSquare, Plus, Search, Trash2, X } from "lucide-react";
import { cn } from "@/lib/cn";
import { loadLocalConversations, saveLocalConversations, type LocalConversation } from "@/lib/chat-storage";

function makeConversation(): LocalConversation {
  const now = new Date().toISOString();
  return { id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, title: "New conversation", updatedAt: now, messages: [] };
}

export function ChatInterface() {
  const [conversations, setConversations] = useState<LocalConversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [historyOpen, setHistoryOpen] = useState(false);
  const [storageWarning, setStorageWarning] = useState(false);
  const [ready, setReady] = useState(false);
  const historyCloseRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const stored = loadLocalConversations();
    setConversations(stored);
    setActiveId(stored[0]?.id ?? null);
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) setStorageWarning(!saveLocalConversations(conversations));
  }, [conversations, ready]);

  useEffect(() => {
    if (!historyOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    historyCloseRef.current?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setHistoryOpen(false);
        return;
      }
      if (event.key === "Tab") {
        const dialog = document.querySelector('[role="dialog"][aria-label="Conversation history"]');
        const focusable = dialog?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), a[href]');
        if (!focusable?.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [historyOpen]);

  const active = conversations.find((item) => item.id === activeId) ?? null;
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return conversations.filter((item) => !term || item.title.toLowerCase().includes(term) || item.messages.some((message) => message.content.toLowerCase().includes(term)));
  }, [conversations, search]);

  const createConversation = () => {
    const next = makeConversation();
    setConversations((items) => [next, ...items]);
    setActiveId(next.id);
    setHistoryOpen(false);
  };

  const deleteConversation = (id: string) => {
    const remaining = conversations.filter((item) => item.id !== id);
    setConversations(remaining);
    if (activeId === id) setActiveId(remaining[0]?.id ?? null);
  };

  const handleSend = (text: string) => {
    const now = new Date().toISOString();
    const current = active ?? makeConversation();
    const message: Message = { id: `msg-${Date.now()}`, role: "user", content: text, createdAt: now };
    const title = current.messages.length === 0 ? text.slice(0, 42) || "New conversation" : current.title;
    const updated: LocalConversation = { ...current, title, updatedAt: now, messages: [...current.messages, message] };
    setConversations((items) => [updated, ...items.filter((item) => item.id !== current.id)]);
    setActiveId(updated.id);
  };

  const history = (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between gap-2 p-3">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold">Conversations</h2>
          <button ref={historyCloseRef} type="button" onClick={() => setHistoryOpen(false)} className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--text-tertiary)] md:hidden" aria-label="Close conversation history"><X size={16} /></button>
        </div>
        <button type="button" onClick={createConversation} className="flex h-9 items-center gap-1.5 rounded-lg bg-[var(--accent-muted)] px-3 text-xs font-semibold text-[var(--accent)]" aria-label="Create conversation"><Plus size={15} /> New</button>
      </div>
      <label className="mx-3 mb-3 flex items-center gap-2 rounded-lg border border-[var(--border)] px-3 py-2 text-[var(--text-tertiary)]">
        <Search size={15} />
        <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search conversations" className="min-w-0 flex-1 bg-transparent text-sm text-[var(--text-primary)] outline-none" aria-label="Search conversations" />
        {search && <button type="button" onClick={() => setSearch("")} aria-label="Clear search"><X size={14} /></button>}
      </label>
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-2 pb-3">
        {filtered.length === 0 ? <div className="px-3 py-6 text-center text-xs text-[var(--text-tertiary)]"><p>{search ? "No matching conversations." : "No conversations yet."}</p>{search && <button type="button" onClick={() => setSearch("")} className="mt-2 font-semibold text-[var(--accent)]">Clear search</button>}</div> : filtered.map((item) => (
          <div key={item.id} className={cn("group flex items-center gap-1 rounded-lg", activeId === item.id ? "bg-[var(--accent-muted)]" : "hover:bg-[var(--bg-hover)]")}>
            <button type="button" onClick={() => { setActiveId(item.id); setHistoryOpen(false); }} className={cn("min-w-0 flex-1 px-3 py-2.5 text-left text-sm", activeId === item.id ? "text-[var(--accent)]" : "text-[var(--text-secondary)]")}>
              <span className="block truncate font-medium">{item.title}</span>
              <span className="mt-0.5 block truncate text-[11px] opacity-70">{item.messages.at(-1)?.content ?? "Empty conversation"}</span>
            </button>
            <button type="button" onClick={() => deleteConversation(item.id)} className="mr-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-[var(--text-tertiary)] hover:text-[var(--danger)]" aria-label={`Delete ${item.title}`}><Trash2 size={15} /></button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="flex h-full min-h-0 flex-col md:flex-row">
      <aside className="hidden w-72 shrink-0 border-r border-[var(--border-subtle)] md:block">{history}</aside>
      {historyOpen && <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Conversation history">
        <button type="button" className="absolute inset-0 bg-black/60" onClick={() => setHistoryOpen(false)} aria-label="Close conversation history" />
        <aside className="absolute inset-y-0 left-0 w-[min(21rem,88vw)] border-r border-[var(--border)] bg-[var(--bg-elevated)] pt-[env(safe-area-inset-top)]">{history}</aside>
      </div>}
      <section className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-[var(--border-subtle)] px-4 py-2 md:hidden">
          <button type="button" onClick={() => setHistoryOpen(true)} className="rounded-lg px-3 py-2 text-sm text-[var(--text-secondary)]" aria-label="Open conversation history">History</button>
          <button type="button" onClick={createConversation} className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm text-[var(--accent)]"><Plus size={16} /> New chat</button>
        </div>
        {storageWarning && <div role="status" className="flex items-center gap-2 border-b border-[var(--warning)]/30 bg-[var(--warning)]/10 px-4 py-2 text-xs text-[var(--text-secondary)]"><AlertCircle size={15} /> Browser storage is unavailable. This conversation may not persist after closing the app.</div>}
        <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4">
          {!active || active.messages.length === 0 ? <EmptyState icon={<MessageSquare className="h-6 w-6" />} title="Start a conversation" description="Your messages are stored locally on this device. NEXUS-AI does not have a connected AI service yet, so it will not generate assistant replies." /> : <div className="mx-auto max-w-3xl space-y-4">{active.messages.map((message) => <MessageBubble key={message.id} message={message} />)}</div>}
        </div>
        <div className="border-t border-[var(--border-subtle)] px-3 py-3">
          <p className="mx-auto mb-2 max-w-3xl text-[11px] text-[var(--text-tertiary)]">Local preview · No AI provider connected · Messages stay in this browser</p>
          <ChatInput onSend={handleSend} placeholder="Write a message…" />
        </div>
      </section>
    </div>
  );
}
