export const mainNav = [
  { href: "/home", label: "Home", icon: "Home" },
  { href: "/chat", label: "Chat", icon: "MessageSquare" },
  { href: "/projects", label: "Projects", icon: "FolderKanban" },
  { href: "/agents", label: "Agents", icon: "Bot" },
  { href: "/tasks", label: "Tasks", icon: "ListTodo" },
  { href: "/tools", label: "Integrations", icon: "Wrench" },
  { href: "/activity", label: "Activity", icon: "Activity" },
] as const;

/** Primary mobile bottom tabs (AgentOS-style density) */
export const bottomNav = [
  { href: "/home", label: "Home", icon: "Home" },
  { href: "/tasks", label: "Tasks", icon: "ListTodo" },
  { href: "/chat", label: "Chat", icon: "MessageSquare" },
  { href: "/agents", label: "Agents", icon: "Bot" },
  { href: "/tools", label: "Integrations", icon: "Wrench" },
] as const;
