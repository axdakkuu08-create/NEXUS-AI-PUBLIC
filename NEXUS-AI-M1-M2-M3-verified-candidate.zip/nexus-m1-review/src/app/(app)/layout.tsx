"use client";

import { useEffect, useRef, useState } from "react";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import { AppHeader } from "@/components/layout/AppHeader";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import Link from "next/link";
import { mainNav } from "@/components/layout/nav-items";
import {
  Home,
  MessageSquare,
  FolderKanban,
  Bot,
  ListTodo,
  Wrench,
  Activity,
  Settings,
  X,
  Sparkles,
} from "lucide-react";

const icons: Record<string, React.ComponentType<{ className?: string }>> = {
  Home,
  MessageSquare,
  FolderKanban,
  Bot,
  ListTodo,
  Wrench,
  Activity,
  Settings,
};

const titles: Record<string, string> = {
  "/home": "Home",
  "/": "Home",
  "/chat": "Chat",
  "/projects": "Projects",
  "/agents": "Agents",
  "/tasks": "Tasks",
  "/tools": "Tools",
  "/activity": "Activity",
  "/settings": "Settings",
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const pathname = usePathname();
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!drawerOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeButtonRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setDrawerOpen(false);
        return;
      }
      if (event.key === "Tab") {
        const panel = document.querySelector('[role="dialog"][aria-label="Main navigation"]');
        const focusable = panel?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])');
        if (!focusable?.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [drawerOpen]);
  const title =
    titles[pathname] ??
    Object.entries(titles).find(([k]) => pathname.startsWith(k) && k !== "/")?.[1] ??
    "NEXUS-AI";

  return (
    <div className="flex h-[100dvh] overflow-hidden">
      <AppSidebar />

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Main navigation">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] bg-[var(--bg-elevated)] border-r border-[var(--border)] flex flex-col safe-top">
            <div className="flex h-14 items-center justify-between px-4 border-b border-[var(--border-subtle)]">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--accent)]/20 text-[var(--accent)]">
                  <Sparkles className="h-4 w-4" />
                </div>
                <span className="font-semibold">NEXUS-AI</span>
              </div>
              <button
                ref={closeButtonRef}
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="h-10 w-10 flex items-center justify-center rounded-lg text-[var(--text-secondary)]"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
              {mainNav.map((item) => {
                const Icon = icons[item.icon] ?? Home;
                const active =
                  item.href === "/"
                    ? pathname === "/" || pathname === "/home"
                    : pathname.startsWith(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href === "/" ? "/home" : item.href}
                    onClick={() => setDrawerOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium",
                      active
                        ? "bg-[var(--accent-muted)] text-[var(--accent)]"
                        : "text-[var(--text-secondary)]"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    {item.label}
                  </Link>
                );
              })}
              <Link
                href="/settings"
                onClick={() => setDrawerOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium",
                  pathname.startsWith("/settings")
                    ? "bg-[var(--accent-muted)] text-[var(--accent)]"
                    : "text-[var(--text-secondary)]"
                )}
              >
                <Settings className="h-5 w-5" />
                Settings
              </Link>
            </nav>
          </div>
        </div>
      )}

      <div className="flex flex-1 flex-col min-w-0">
        <AppHeader title={title} onMenuClick={() => setDrawerOpen(true)} />
        <main className="flex-1 overflow-y-auto overflow-x-hidden pb-16 md:pb-0">
          {children}
        </main>
        <MobileNavigation />
      </div>
    </div>
  );
}
