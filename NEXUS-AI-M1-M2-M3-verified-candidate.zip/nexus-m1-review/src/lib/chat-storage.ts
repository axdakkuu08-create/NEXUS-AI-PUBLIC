import type { Message } from "@/lib/types";

export interface LocalConversation {
  id: string;
  title: string;
  updatedAt: string;
  messages: Message[];
}

const STORAGE_KEY = "nexus-ai.local-conversations.v1";

function isMessage(value: unknown): value is Message {
  if (!value || typeof value !== "object") return false;
  const item = value as Record<string, unknown>;
  return typeof item.id === "string" &&
    (item.role === "user" || item.role === "assistant" || item.role === "system") &&
    typeof item.content === "string" && typeof item.createdAt === "string";
}

function isConversation(value: unknown): value is LocalConversation {
  if (!value || typeof value !== "object") return false;
  const item = value as Record<string, unknown>;
  return typeof item.id === "string" && typeof item.title === "string" &&
    typeof item.updatedAt === "string" && Array.isArray(item.messages) &&
    item.messages.every(isMessage);
}

export function loadLocalConversations(): LocalConversation[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter(isConversation) : [];
  } catch {
    return [];
  }
}

export function saveLocalConversations(items: LocalConversation[]): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    return true;
  } catch {
    return false;
  }
}
