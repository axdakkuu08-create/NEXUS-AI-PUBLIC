# NEXUS-AI Frontend (M1–M3 recovery candidate)

Premium **mobile-first** AI agent workspace.  
Visual direction: dark black-green surfaces, neon emerald accents (AgentOS-inspired).

## Stack

- Next.js 16 (App Router) + React 19 + TypeScript
- Tailwind CSS v4
- lucide-react

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Screens

Home · Chat (Command Center) · Projects · Agents · Tasks · Integrations · Activity · Settings

## Design

See `docs/DESIGN_SYSTEM.md` and `docs/FRONTEND_UI_SPEC.md`.

## Current implementation status

- M1 foundation and M2 dashboard/navigation are frontend-only.
- M3 chat supports local conversation creation, selection, deletion, search, and browser storage.
- No AI provider, authentication, Convex backend, cloud sync, or file upload is connected.
- `src/lib/services.ts` contains disconnected backend service stubs. They must not be presented as successful operations.
- Local chat data is stored in the current browser profile and can be cleared by browser storage cleanup.

## Verification

See `docs/NEXUS-AI-M1-M2-M3-RECOVERY-VERIFICATION.md` for checks actually run and remaining blockers. Dependency-backed lint, type-check, production build, and mobile runtime tests are still required before release.

```bash
npm install
npm run lint
npm run typecheck
npm run build
```
