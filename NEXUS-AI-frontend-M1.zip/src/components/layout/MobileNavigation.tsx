"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import { bottomNav } from "./nav-items";
import {
  Home,
  MessageSquare,
  FolderKanban,
  Bot,
  Settings,
} from "lucide-react";

const icons: Record<string, React.ComponentType<{ className?: string }>> = {
  Home,
  MessageSquare,
  FolderKanban,
  Bot,
  Settings,
};

export function MobileNavigation() {
  const pathname = usePathname();

  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 glass safe-bottom border-t border-[var(--border)]">
      <div className="flex items-stretch justify-around h-14">
        {bottomNav.map((item) => {
          const Icon = icons[item.icon] ?? Home;
          const active =
            item.href === "/"
              ? pathname === "/" || pathname === ""
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-1 flex-col items-center justify-center gap-0.5 text-[10px] font-medium min-w-0",
                active ? "text-[var(--accent)]" : "text-[var(--text-tertiary)]"
              )}
            >
              <Icon className={cn("h-5 w-5", active && "stroke-[2.25]")} />
              <span className="truncate max-w-full px-0.5">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
